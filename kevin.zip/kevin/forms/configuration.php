<?php
//Host Settings
define ("_SMTP_HOST","mail.lucysecurity.com");
define ("_SMTP_USER","alvin@lucysecurity.com");
define ("_SMTP_PASS","cnoZSwD8q5l5lAyqn@hUP");
define ("_SMTP_PORT","465"); //568 - tls

//Mail to Lucy Security
define ("_MAIL_TO","info@lucysecurity.com");
define ("SENDER","info@lucysecurity.com");
define ("SENDERNAME","Lucy Security");

//Mail CC
define ("MAIL_CC_1","sales@lucysecurity.com");
define ("MAIL_CC_2","madel@lucysecurity.com");
define ("MAIL_CC_3","colin@lucysecurity.com");

//Mail BCC
define ("MAIL_BCC_1","");
define ("MAIL_BCC_2","");
define ("MAIL_BCC_3","");

//Captcha v2 (lucyscript@gmail.com, Lucysecurity!)
define ("SECRETKEY","6Lfm-AIcAAAAAHinCe8nSxNYYPlsfKrjLeXXUynr");
define ("PUBLICKEY","6Lfm-AIcAAAAAAFt8pK_K0CT_jLmnfBuFbx6k8E8");

//Captcha v3
define ("SECRETKEYV3","");
define ("PUBLICKEYV3","");
?>