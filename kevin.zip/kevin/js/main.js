new WOW().init();
jQuery(document).ready(function(){
	/*Sticky Header*/
	jQuery(document).on("scroll", function() {
	  if (jQuery(document).scrollTop() > 0) {
		jQuery("body").addClass("header-fixed");
	  } else {
		jQuery("body").removeClass("header-fixed");
	  }
	});
	///Moble Menu Script
	jQuery(".mobilemenuicon").click(function(){
		jQuery(".mobilemenuicon").toggleClass('is-active');
	});

	/* scroll bottom to top */
	if (jQuery(this).scrollTop() > 200) {
		jQuery('.scrollup').fadeIn();
	} else {
		jQuery('.scrollup').fadeOut();
	}
	jQuery(window).scroll(function () {
		if (jQuery(this).scrollTop() > 200) {
			jQuery('.scrollup').fadeIn();
		} else {
			jQuery('.scrollup').fadeOut();
		}
	});
	jQuery('.scrollup').click(function () {
		jQuery("html, body").animate({
			scrollTop: 0
		}, 600);
		return false;
	});

	jQuery('.popup-video a').magnificPopup({
		disableOn: 700,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,
		fixedContentPos: false
	});

});//ready over

jQuery(window).ready(function(){
	if (jQuery(document).scrollTop() > 0) {
	jQuery("body").addClass("header-fixed");
	} else {
	jQuery("body").removeClass("header-fixed");
	}
});

/****** Loader - Start- *****/
jQuery(window).on('load', function() {
	// Animate loader off screen
	jQuery('.loader-wrap').fadeOut();
	jQuery('.spinner').delay(350).fadeOut('slow');
});

//modal import

var modal_import = document.getElementById("myModal-import");
var btn = document.getElementById("importContent");
var span = document.getElementsByClassName("close")[0];

btn.onclick = function() {
  modal_import.style.display = "block";
  $(".overlay").show();
  $('#cloudContent').not(this).prop('checked', false);  
}

span.onclick = function() {
  modal_import.style.display = "none";
  $(".overlay").hide();
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal_import.style.display = "none";
  }
}

//modal cloud

var modal_cloud = document.getElementById("myModal-cloud");
var btn_cloud = document.getElementById("cloudContent");
var span_cloud1 = document.getElementsByClassName("close1")[0];

btn_cloud.onclick = function() {
  modal_cloud.style.display = "block";
  $(".overlay").show();
  $('#importContent').not(this).prop('checked', false);  
}

span_cloud1.onclick = function() {
  modal_cloud.style.display = "none";
  $(".overlay").hide();
}

window.onclick = function(event) {
  if (event.target == modal_cloud) {
    modal_cloud.style.display = "none";
  }
}

